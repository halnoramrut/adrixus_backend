var mongoose = require("mongoose");
const { Schema } = mongoose;

// Add the following columns in it and their datatypes
const dummyData = Schema({
	firstname: String,
	lastname: String,
	phonenumber: String,
	city: String,
});

// Require it as the output
module.exports = mongoose.model("dummyData", dummyData);